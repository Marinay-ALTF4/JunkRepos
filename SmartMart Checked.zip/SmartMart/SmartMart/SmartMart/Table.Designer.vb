﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Table
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Customer = New Button()
        Order = New Button()
        Product = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 80F)
        Label1.Location = New Point(131, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(559, 142)
        Label1.TabIndex = 0
        Label1.Text = "SmartMart"
        ' 
        ' Customer
        ' 
        Customer.Location = New Point(28, 201)
        Customer.Name = "Customer"
        Customer.Size = New Size(192, 58)
        Customer.TabIndex = 1
        Customer.Text = "Customer"
        Customer.UseVisualStyleBackColor = True
        ' 
        ' Order
        ' 
        Order.Location = New Point(291, 201)
        Order.Name = "Order"
        Order.Size = New Size(192, 58)
        Order.TabIndex = 2
        Order.Text = "Order"
        Order.UseVisualStyleBackColor = True
        ' 
        ' Product
        ' 
        Product.Location = New Point(562, 201)
        Product.Name = "Product"
        Product.Size = New Size(192, 58)
        Product.TabIndex = 3
        Product.Text = "Product"
        Product.UseVisualStyleBackColor = True
        ' 
        ' Table
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Product)
        Controls.Add(Order)
        Controls.Add(Customer)
        Controls.Add(Label1)
        Name = "Table"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Customer As Button
    Friend WithEvents Order As Button
    Friend WithEvents Product As Button

End Class
