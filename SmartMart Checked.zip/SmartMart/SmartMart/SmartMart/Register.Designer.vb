﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        TextContact = New TextBox()
        TextAddress = New TextBox()
        TextName = New TextBox()
        TextCity = New TextBox()
        Register1 = New Button()
        Back1 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 50F)
        Label1.Location = New Point(115, 12)
        Label1.Name = "Label1"
        Label1.Size = New Size(744, 112)
        Label1.TabIndex = 0
        Label1.Text = "Register Customer:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 20F)
        Label2.Location = New Point(115, 161)
        Label2.Name = "Label2"
        Label2.Size = New Size(125, 46)
        Label2.TabIndex = 1
        Label2.Text = "Name: "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 20F)
        Label3.Location = New Point(115, 436)
        Label3.Name = "Label3"
        Label3.Size = New Size(164, 46)
        Label3.TabIndex = 2
        Label3.Text = "Contact#:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 20F)
        Label4.Location = New Point(115, 343)
        Label4.Name = "Label4"
        Label4.Size = New Size(84, 46)
        Label4.TabIndex = 3
        Label4.Text = "City:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 20F)
        Label5.Location = New Point(115, 255)
        Label5.Name = "Label5"
        Label5.Size = New Size(147, 46)
        Label5.TabIndex = 4
        Label5.Text = "Address:"
        ' 
        ' TextContact
        ' 
        TextContact.Location = New Point(272, 455)
        TextContact.Margin = New Padding(3, 4, 3, 4)
        TextContact.Name = "TextContact"
        TextContact.Size = New Size(374, 27)
        TextContact.TabIndex = 5
        ' 
        ' TextAddress
        ' 
        TextAddress.Location = New Point(270, 273)
        TextAddress.Margin = New Padding(3, 4, 3, 4)
        TextAddress.Name = "TextAddress"
        TextAddress.Size = New Size(374, 27)
        TextAddress.TabIndex = 6
        ' 
        ' TextName
        ' 
        TextName.Location = New Point(270, 180)
        TextName.Margin = New Padding(3, 4, 3, 4)
        TextName.Name = "TextName"
        TextName.Size = New Size(374, 27)
        TextName.TabIndex = 7
        ' 
        ' TextCity
        ' 
        TextCity.Location = New Point(272, 361)
        TextCity.Margin = New Padding(3, 4, 3, 4)
        TextCity.Name = "TextCity"
        TextCity.Size = New Size(374, 27)
        TextCity.TabIndex = 8
        ' 
        ' Register1
        ' 
        Register1.Location = New Point(205, 513)
        Register1.Margin = New Padding(3, 4, 3, 4)
        Register1.Name = "Register1"
        Register1.Size = New Size(146, 56)
        Register1.TabIndex = 9
        Register1.Text = "Register"
        Register1.UseVisualStyleBackColor = True
        ' 
        ' Back1
        ' 
        Back1.Location = New Point(462, 513)
        Back1.Margin = New Padding(3, 4, 3, 4)
        Back1.Name = "Back1"
        Back1.Size = New Size(146, 56)
        Back1.TabIndex = 10
        Back1.Text = "Back"
        Back1.UseVisualStyleBackColor = True
        ' 
        ' Register
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(914, 600)
        Controls.Add(Back1)
        Controls.Add(Register1)
        Controls.Add(TextCity)
        Controls.Add(TextName)
        Controls.Add(TextAddress)
        Controls.Add(TextContact)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Margin = New Padding(3, 4, 3, 4)
        Name = "Register"
        Text = "Register"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextContact As TextBox
    Friend WithEvents TextAddress As TextBox
    Friend WithEvents TextName As TextBox
    Friend WithEvents TextCity As TextBox
    Friend WithEvents Register1 As Button
    Friend WithEvents Back1 As Button
End Class
