﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Dashboard

    ' ====== MONGODB CLIENT & COLLECTION ======
    Public Shared MongoClient As MongoClient
    Public Shared MongoDatabase As IMongoDatabase
    Public Shared CustomersCollection As IMongoCollection(Of BsonDocument)

    ' ====== DASHBOARD LOAD ======
    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConnectToMongoDB()
        InitializeColumns()
        LoadCustomersFromDB()
    End Sub

    ' ====== MONGODB CONNECTION FUNCTION ======
    Public Sub ConnectToMongoDB()
        Try
            Dim connectionString As String = "mongodb://localhost:27017"
            MongoClient = New MongoClient(connectionString)

            MongoDatabase = MongoClient.GetDatabase("SmartMartDB")
            CustomersCollection = MongoDatabase.GetCollection(Of BsonDocument)("Customers")

        Catch ex As Exception
            MsgBox("MongoDB Connection Failed: " & ex.Message)
        End Try
    End Sub

    ' ====== INITIALIZE DATAGRID COLUMNS ======
    Private Sub InitializeColumns()
        DataGridView1.Columns.Clear()
        DataGridView1.AutoGenerateColumns = False

        ' Add columns
        DataGridView1.Columns.Add("Name", "Name")
        DataGridView1.Columns.Add("Address", "Address")
        DataGridView1.Columns.Add("City", "City")
        DataGridView1.Columns.Add("Contact", "Contact")

        ' Optional: Set column widths
        DataGridView1.Columns("Name").Width = 150
        DataGridView1.Columns("Address").Width = 200
        DataGridView1.Columns("City").Width = 100
        DataGridView1.Columns("Contact").Width = 120
    End Sub

    ' ====== LOAD CUSTOMERS FROM DATABASE ======
    Public Sub LoadCustomersFromDB()
        Try
            DataGridView1.Rows.Clear()

            Dim customers = CustomersCollection.Find(New BsonDocument()).ToList()

            For Each cust In customers
                DataGridView1.Rows.Add(cust("Name").AsString,
                                       cust("Address").AsString,
                                       cust("City").AsString,
                                       cust("Contact").AsString)
            Next

        Catch ex As Exception
            MsgBox("Failed to load customers: " & ex.Message)
        End Try
    End Sub

    ' ====== OPEN REGISTER FORM ======
    Private Sub Register_Click(sender As Object, e As EventArgs) Handles Register.Click
        Dim regForm As New Register()
        regForm.Show()
        Me.Hide()
    End Sub

    Private Sub Update_Click(sender As Object, e As EventArgs) Handles Update.Click
        Dim UpdateForm As New Update()
        UpdateForm.Show()
        Me.Hide()
    End Sub

    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
        ' Check if a row is selected
        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox("Please select a customer to delete.")
            Exit Sub
        End If

        ' Confirm deletion
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this customer?",
                                                     "Delete Customer",
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Warning)
        If result = DialogResult.Yes Then
            Try
                ' Get selected row values
                Dim selectedRow = DataGridView1.SelectedRows(0)
                Dim name As String = selectedRow.Cells("Name").Value.ToString()
                Dim contact As String = selectedRow.Cells("Contact").Value.ToString()

                ' Build filter for MongoDB
                Dim filter As New BsonDocument From {
                    {"Name", name},
                    {"Contact", contact}
                }

                ' Delete from MongoDB
                CustomersCollection.DeleteOne(filter)

                ' Remove from DataGridView
                DataGridView1.Rows.Remove(selectedRow)

                MsgBox("Customer deleted successfully!")

            Catch ex As Exception
                MsgBox("Failed to delete customer: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub refresh_Click(sender As Object, e As EventArgs) Handles refresh.Click
        LoadCustomersFromDB()
    End Sub
End Class
