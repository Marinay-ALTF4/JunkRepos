﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        DataGridView1 = New DataGridView()
        Update = New Button()
        Register = New Button()
        Delete = New Button()
        refresh = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 50F)
        Label1.Location = New Point(162, 12)
        Label1.Name = "Label1"
        Label1.Size = New Size(608, 112)
        Label1.TabIndex = 0
        Label1.Text = "Customer Page"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(14, 159)
        DataGridView1.Margin = New Padding(3, 4, 3, 4)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(887, 279)
        DataGridView1.TabIndex = 1
        ' 
        ' Update
        ' 
        Update.Location = New Point(30, 445)
        Update.Margin = New Padding(3, 4, 3, 4)
        Update.Name = "Update"
        Update.Size = New Size(143, 68)
        Update.TabIndex = 2
        Update.Text = "Update"
        Update.UseVisualStyleBackColor = True
        ' 
        ' Register
        ' 
        Register.Location = New Point(256, 445)
        Register.Margin = New Padding(3, 4, 3, 4)
        Register.Name = "Register"
        Register.Size = New Size(143, 68)
        Register.TabIndex = 3
        Register.Text = "Register"
        Register.UseVisualStyleBackColor = True
        ' 
        ' Delete
        ' 
        Delete.Location = New Point(479, 445)
        Delete.Margin = New Padding(3, 4, 3, 4)
        Delete.Name = "Delete"
        Delete.Size = New Size(143, 68)
        Delete.TabIndex = 4
        Delete.Text = "Delete"
        Delete.UseVisualStyleBackColor = True
        ' 
        ' refresh
        ' 
        refresh.Location = New Point(712, 445)
        refresh.Margin = New Padding(3, 4, 3, 4)
        refresh.Name = "refresh"
        refresh.Size = New Size(143, 68)
        refresh.TabIndex = 5
        refresh.Text = "Refresh"
        refresh.UseVisualStyleBackColor = True
        ' 
        ' Dashboard
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(914, 600)
        Controls.Add(refresh)
        Controls.Add(Delete)
        Controls.Add(Register)
        Controls.Add(Update)
        Controls.Add(DataGridView1)
        Controls.Add(Label1)
        Margin = New Padding(3, 4, 3, 4)
        Name = "Dashboard"
        Text = "Dashboard"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Update As Button
    Friend WithEvents Register As Button
    Friend WithEvents Delete As Button
    Friend WithEvents refresh As Button
End Class
