﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Register

    ' ===== REGISTER BUTTON =====
    Private Sub Register1_Click(sender As Object, e As EventArgs) Handles Register1.Click

        ' Validate empty fields
        If TextName.Text = "" Or TextAddress.Text = "" Or TextCity.Text = "" Or TextContact.Text = "" Then
            MsgBox("Please fill out all fields.")
            Exit Sub
        End If

        ' --- Connect to MongoDB ---
        MongoDBConnection.Connect()
        Dim collection = MongoDBConnection.GetCustomersCollection()

        ' --- Create new customer document ---
        Dim doc As New BsonDocument From {
            {"Name", TextName.Text},
            {"Address", TextAddress.Text},
            {"City", TextCity.Text},
            {"Contact", TextContact.Text}
        }

        ' --- Insert into MongoDB ---
        collection.InsertOne(doc)

        MsgBox("Customer registered successfully!")

        ' --- Clear fields ---
        TextName.Clear()
        TextAddress.Clear()
        TextCity.Clear()
        TextContact.Clear()

    End Sub

    ' ===== BACK BUTTON =====
    Private Sub Back1_Click(sender As Object, e As EventArgs) Handles Back1.Click
        Dashboard.Show()
        Me.Hide()
    End Sub

End Class
