﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Update

    ' ===== Store selected row info =====
    Private originalName As String
    Private originalContact As String

    ' ===== FORM LOAD =====
    Private Sub Update_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeColumns()
        LoadCustomersIntoTable()
    End Sub

    ' ===== INITIALIZE DATAGRID COLUMNS =====
    Private Sub InitializeColumns()
        CustomerTable.Columns.Clear()
        CustomerTable.AutoGenerateColumns = False

        CustomerTable.Columns.Add("Name", "Name")
        CustomerTable.Columns.Add("Address", "Address")
        CustomerTable.Columns.Add("City", "City")
        CustomerTable.Columns.Add("Contact", "Contact")
        CustomerTable.Columns.Add("LoyaltyPoints", "Loyalty Points")

        ' Optional column widths
        CustomerTable.Columns("Name").Width = 150
        CustomerTable.Columns("Address").Width = 200
        CustomerTable.Columns("City").Width = 100
        CustomerTable.Columns("Contact").Width = 120
        CustomerTable.Columns("LoyaltyPoints").Width = 80
    End Sub

    ' ===== LOAD CUSTOMERS INTO DATAGRID =====
    Private Sub LoadCustomersIntoTable()
        CustomerTable.Rows.Clear()
        Try
            Dim customers = Dashboard.CustomersCollection.Find(New BsonDocument()).ToList()
            For Each cust In customers
                CustomerTable.Rows.Add(
                    cust("Name").AsString,
                    cust("Address").AsString,
                    cust("City").AsString,
                    cust("Contact").AsString,
                    If(cust.Contains("LoyaltyPoints"), cust("LoyaltyPoints").AsInt32, 0)
                )
            Next
        Catch ex As Exception
            MsgBox("Failed to load customers: " & ex.Message)
        End Try
    End Sub

    ' ===== WHEN A ROW IS CLICKED =====
    Private Sub CustomerTable_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles CustomerTable.CellClick
        If e.RowIndex >= 0 Then
            Dim row = CustomerTable.Rows(e.RowIndex)

            TxtName.Text = row.Cells("Name").Value.ToString()
            TxtAddress.Text = row.Cells("Address").Value.ToString()
            TxtCity.Text = row.Cells("City").Value.ToString()
            TxtContact.Text = row.Cells("Contact").Value.ToString()
            TxtLoyalty.Text = row.Cells("LoyaltyPoints").Value.ToString()  ' <-- Use TxtLoyalty

            ' Save original keys for updating
            originalName = TxtName.Text
            originalContact = TxtContact.Text
        End If
    End Sub

    ' ===== UPDATE BUTTON =====
    Private Sub Updates_Click(sender As Object, e As EventArgs) Handles Updates.Click
        ' Validate fields
        If TxtName.Text = "" Or TxtAddress.Text = "" Or TxtCity.Text = "" Or TxtContact.Text = "" Or TxtLoyalty.Text = "" Then
            MsgBox("Please fill out all fields.")
            Exit Sub
        End If

        Try
            Dim collection = Dashboard.CustomersCollection

            ' Filter: match by original Name + Contact
            Dim filter As New BsonDocument From {
                {"Name", originalName},
                {"Contact", originalContact}
            }

            ' Update values including LoyaltyPoints
            Dim update As New BsonDocument("$set", New BsonDocument From {
                {"Name", TxtName.Text},
                {"Address", TxtAddress.Text},
                {"City", TxtCity.Text},
                {"Contact", TxtContact.Text},
                {"LoyaltyPoints", Convert.ToInt32(TxtLoyalty.Text)}
            })

            collection.UpdateOne(filter, update)

            MsgBox("Customer updated successfully!")
            LoadCustomersIntoTable() ' Refresh table after update

        Catch ex As Exception
            MsgBox("Failed to update customer: " & ex.Message)
        End Try
    End Sub

    ' ===== BACK BUTTON =====
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Dashboard.Show()
        Me.Hide()
    End Sub

End Class
