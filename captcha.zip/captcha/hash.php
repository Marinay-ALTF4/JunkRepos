<?php
require __DIR__ . '/connection.php';

$email = 'sample@example.com';
$plain = 'password123';
$hash  = password_hash($plain, PASSWORD_DEFAULT);

// Ensure table exists
$conn->query('CREATE TABLE IF NOT EXISTS users (
	id INT AUTO_INCREMENT PRIMARY KEY,
	email VARCHAR(255) NOT NULL UNIQUE,
	password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

// Check if user already exists
$check = $conn->prepare('SELECT 1 FROM users WHERE email = ? LIMIT 1');
if (!$check) {
	die('Prepare failed: ' . $conn->error);
}
$check->bind_param('s', $email);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
	$check->close();
	die('User already exists: ' . $email);
}
$check->close();

$stmt = $conn->prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)');
if (!$stmt) {
	die('Prepare failed: ' . $conn->error);
}
$stmt->bind_param('ss', $email, $hash);
if (!$stmt->execute()) {
	die('Insert failed: ' . $stmt->error);
}

echo 'Inserted user ' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . ' with password ' . htmlspecialchars($plain, ENT_QUOTES, 'UTF-8');

$stmt->close();
$conn->close();