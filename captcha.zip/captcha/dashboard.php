<?php
session_start();

if (!isset($_SESSION['user_email'])) {
	header('Location: login.php');
	exit;
}

$userEmail = $_SESSION['user_email'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Dashboard</title>
	<style>
		body { font-family: Arial, sans-serif; background: #f2f4f8; margin: 0; padding: 0; }
		.container { max-width: 640px; margin: 60px auto; background: #fff; padding: 32px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); text-align: center; }
		h1 { margin-top: 0; }
		.logout { margin-top: 24px; display: inline-block; padding: 10px 18px; background: #b00020; color: #fff; text-decoration: none; border-radius: 6px; }
		.logout:hover { background: #8c001a; }
	</style>
</head>
<body>
	<div class="container">
		<h1>Welcome to dashboard</h1>
		<p>You are logged in as <?= htmlspecialchars($userEmail, ENT_QUOTES, 'UTF-8') ?>.</p>
		<a class="logout" href="logout.php">Logout</a>
	</div>
</body>
</html>
