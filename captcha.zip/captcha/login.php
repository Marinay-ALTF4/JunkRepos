<?php
session_start();
require __DIR__ . '/connection.php';

if (isset($_SESSION['user_email'])) {
    header('Location: dashboard.php');
    exit;
}

//    CONFIGURATION
$recaptchaSiteKey = '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI';   // Test Site Key
$recaptchaSecret  = '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe';   // Test Secret Key


$errors  = [];
$success = null;



//    FUNCTION: VERIFY RECAPTCHA
function verifyRecaptcha($secret, $response)
{
    $payload = http_build_query([
        'secret'   => $secret,
        'response' => $response,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ]);

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'content' => $payload,
            'timeout' => 5,
        ],
    ];

    $context = stream_context_create($options);
    $verify  = @file_get_contents(
        'https://www.google.com/recaptcha/api/siteverify',
        false,
        $context
    );

    if ($verify === false) {
        return false;
    }

    $result = json_decode($verify, true);

    return $result['success'] ?? false;
}



//    HANDLE FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $recaptchaResponse = $_POST['g-recaptcha-response'] ?? '';

    // Basic validation
    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    }

    if ($recaptchaResponse === '') {
        $errors[] = 'Captcha is required.';
    }

    // Verify reCAPTCHA
    if (empty($errors)) {
        if (!verifyRecaptcha($recaptchaSecret, $recaptchaResponse)) {
            $errors[] = 'Captcha failed. Please try again.';
        }
    }

    // Login user
    if (empty($errors)) {

        $stmt = $conn->prepare("SELECT password_hash FROM users WHERE email = ? LIMIT 1");

        if ($stmt) {

            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->bind_result($passwordHash);

            if ($stmt->fetch() && password_verify($password, $passwordHash)) {

                $_SESSION['user_email'] = $email;
                header('Location: dashboard.php');
                exit;

            } else {
                $errors[] = "Invalid credentials.";
            }

            $stmt->close();

        } else {
            $errors[] = "Login failed (query error).";
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login with reCAPTCHA</title>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>


</head>

<body>
<div class="container">
<h1>Login</h1>

<?php if (!empty($errors)): ?>
<div class="errors">
    <?php foreach ($errors as $error): ?>
        <div><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<form method="post" novalidate>

    <label>Email</label>
    <input type="email" name="email"
        value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
        required>

    <label>Password</label>
    <input type="password" name="password" required>

    <div class="g-recaptcha"
        data-sitekey="<?= htmlspecialchars($recaptchaSiteKey, ENT_QUOTES, 'UTF-8') ?>">
    </div>

    <button type="submit">Sign in</button>

</form>
</div>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f2f4f8;
}
.container {
    max-width: 420px;
    margin: 60px auto;
    background: #fff;
    padding: 32px;
    border-radius: 8px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}
h1 { text-align: center; }
label { font-weight: bold; }
input {
    width: 100%;
    padding: 10px;
    margin-bottom: 14px;
    border: 1px solid #ccc;
    border-radius: 6px;
}
button {
    width: 100%;
    padding: 12px;
    background: #2b6cb0;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
button:hover {
    background: #245a94;
}
.errors { color: red; margin-bottom: 10px; }
.success { color: green; margin-bottom: 10px; }
.g-recaptcha { margin-bottom: 16px; }
</style>
</body>
</html>


<!-- CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; -->

<!-- INSERT INTO users (email, password_hash)
VALUES ('test@example.com', 'test123'); -->


