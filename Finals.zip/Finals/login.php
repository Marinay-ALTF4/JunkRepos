<?php
require_once 'database.php';
require_once 'session.php';

ensureSessionStarted();

if (!empty($_SESSION['logged_in'])) {
	header('Location: dashboard.php');
	exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$username = trim($_POST['username'] ?? '');
	$password = $_POST['password'] ?? '';
	$captcha = $_POST['captcha'] ?? '';

	if ($username === '' || $password === '' || $captcha === '') {
		$error = 'All fields are required.';
	} elseif (!validateCaptcha($captcha)) {
		$error = 'Invalid captcha.';
	} else {
		$stmt = $conn->prepare('SELECT id, username, password FROM users WHERE username = ? LIMIT 1');
		$stmt->bind_param('s', $username);
		$stmt->execute();
		$result = $stmt->get_result();
		$user = $result->fetch_assoc();
		$stmt->close();

		if ($user && password_verify($password, $user['password'])) {
			startSession($user);
			unset($_SESSION['captcha_answer']);
			header('Location: dashboard.php');
			exit;
		}

		$error = 'Invalid username or password.';
	}
}

$captchaQuestion = generateCaptcha();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login</title>
	<style>
		body { font-family: Arial, sans-serif; background: #f5f6fa; margin: 0; }
		.card { max-width: 420px; margin: 60px auto; background: #fff; padding: 24px; border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,0.08); }
		h1 { margin-top: 0; font-size: 24px; }
		label { display: block; margin: 12px 0 6px; }
		input { width: 100%; padding: 10px; border: 1px solid #dcdde1; border-radius: 6px; box-sizing: border-box; }
		button { margin-top: 16px; width: 100%; background: #2f3640; color: #fff; border: 0; padding: 10px; border-radius: 6px; cursor: pointer; }
		.error { background: #fdecea; color: #b71c1c; padding: 10px; border-radius: 6px; margin-bottom: 10px; }
		.link { margin-top: 14px; text-align: center; }
	</style>
</head>
<body>
	<div class="card">
		<h1>Login</h1>

		<?php if (!empty($_GET['error'])): ?>
			<div class="error"><?php echo htmlspecialchars($_GET['error']); ?></div>
		<?php endif; ?>

		<?php if ($error !== ''): ?>
			<div class="error"><?php echo htmlspecialchars($error); ?></div>
		<?php endif; ?>

		<form method="post" action="">
			<label for="username">Username</label>
			<input type="text" id="username" name="username" required>

			<label for="password">Password</label>
			<input type="password" id="password" name="password" required>

			<label for="captcha">Captcha: <?php echo htmlspecialchars($captchaQuestion); ?> = ?</label>
			<input type="text" id="captcha" name="captcha" required>

			<button type="submit">Login</button>
		</form>

		<div class="link">No account? <a href="register.php">Register</a></div>
	</div>
</body>
</html>
