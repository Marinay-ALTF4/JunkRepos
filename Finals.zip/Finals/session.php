<?php

function startSession($result) {

	session_start();

	//$fullname = $result['first_name'] . ' ' . $result['middle_name'] . ' ' . $result['last_name'];
	$_SESSION['logged_in'] = true;
   // $_SESSION['fullname'] = $fullname;
	$_SESSION['username'] = $result['username'];
	$_SESSION['LAST_ACTIVITY'] = time();

	// $_SESSION['SESSION_TIMEOUT'] = $session_timeout;
}

function ensureSessionStarted() {
	if (session_status() !== PHP_SESSION_ACTIVE) {
		session_start();
	}
}

function requireLogin() {
	ensureSessionStarted();

	$sessionTimeout = 10;
	if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $sessionTimeout) {
		session_unset();
		session_destroy();
		header('Location: login.php?error=Session expired. Please log in again.');
		exit;
	}

	if (empty($_SESSION['logged_in'])) {
		header('Location: login.php');
		exit;
	}

	$_SESSION['LAST_ACTIVITY'] = time();
}

function generateCaptcha() {
	ensureSessionStarted();
	$a = random_int(1, 9);
	$b = random_int(1, 9);
	$_SESSION['captcha_answer'] = (string)($a + $b);
	return "$a + $b";
}

function validateCaptcha($input) {
	ensureSessionStarted();
	return isset($_SESSION['captcha_answer']) && trim((string)$input) === (string)$_SESSION['captcha_answer'];
}

?>
