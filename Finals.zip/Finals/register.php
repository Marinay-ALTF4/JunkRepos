<?php
require_once 'database.php';
require_once 'session.php';

ensureSessionStarted();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$username = trim($_POST['username'] ?? '');
	$password = $_POST['password'] ?? '';
	$confirmPassword = $_POST['confirm_password'] ?? '';
	$captcha = $_POST['captcha'] ?? '';

	if ($username === '' || $password === '' || $confirmPassword === '' || $captcha === '') {
		$error = 'All fields are required.';
	} elseif ($password !== $confirmPassword) {
		$error = 'Passwords do not match.';
	} elseif (strlen($password) < 6) {
		$error = 'Password must be at least 6 characters.';
	} elseif (!validateCaptcha($captcha)) {
		$error = 'Invalid captcha.';
	} else {
		$checkStmt = $conn->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
		$checkStmt->bind_param('s', $username);
		$checkStmt->execute();
		$exists = $checkStmt->get_result()->fetch_assoc();
		$checkStmt->close();

		if ($exists) {
			$error = 'Username already exists.';
		} else {
			$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
			$insertStmt = $conn->prepare('INSERT INTO users (username, password) VALUES (?, ?)');
			$insertStmt->bind_param('ss', $username, $hashedPassword);

			if ($insertStmt->execute()) {
				$success = 'Registration successful. You can now log in.';
				unset($_SESSION['captcha_answer']);
			} else {
				$error = 'Could not register user. Please try again.';
			}

			$insertStmt->close();
		}
	}
}

$captchaQuestion = generateCaptcha();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Register</title>
	<style>
		body { font-family: Arial, sans-serif; background: #f5f6fa; margin: 0; }
		.card { max-width: 460px; margin: 60px auto; background: #fff; padding: 24px; border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,0.08); }
		h1 { margin-top: 0; font-size: 24px; }
		label { display: block; margin: 12px 0 6px; }
		input { width: 100%; padding: 10px; border: 1px solid #dcdde1; border-radius: 6px; box-sizing: border-box; }
		button { margin-top: 16px; width: 100%; background: #2f3640; color: #fff; border: 0; padding: 10px; border-radius: 6px; cursor: pointer; }
		.error { background: #fdecea; color: #b71c1c; padding: 10px; border-radius: 6px; margin-bottom: 10px; }
		.success { background: #e8f5e9; color: #1b5e20; padding: 10px; border-radius: 6px; margin-bottom: 10px; }
		.link { margin-top: 14px; text-align: center; }
	</style>
</head>
<body>
	<div class="card">
		<h1>Register</h1>

		<?php if ($error !== ''): ?>
			<div class="error"><?php echo htmlspecialchars($error); ?></div>
		<?php endif; ?>

		<?php if ($success !== ''): ?>
			<div class="success"><?php echo htmlspecialchars($success); ?></div>
		<?php endif; ?>

		<form method="post" action="">
			<label for="username">Username</label>
			<input type="text" id="username" name="username" required>

			<label for="password">Password</label>
			<input type="password" id="password" name="password" required>

			<label for="confirm_password">Confirm Password</label>
			<input type="password" id="confirm_password" name="confirm_password" required>

			<label for="captcha">Captcha: <?php echo htmlspecialchars($captchaQuestion); ?> = ?</label>
			<input type="text" id="captcha" name="captcha" required>

			<button type="submit">Register</button>
		</form>

		<div class="link">Already have an account? <a href="login.php">Login</a></div>
	</div>
</body>
</html>
