<?php
require_once 'database.php';
require_once 'session.php';

requireLogin();

if (isset($_GET['logout']) && $_GET['logout'] === '1') {
	ensureSessionStarted();
	session_unset();
	session_destroy();
	header('Location: login.php');
	exit;
}

$view = $_GET['view'] ?? 'home';

$users = [];
if ($view === 'users') {
	$result = $conn->query('SELECT id, username, created_at FROM users ORDER BY id DESC');
	if ($result) {
		while ($row = $result->fetch_assoc()) {
			$users[] = $row;
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Dashboard</title>
	<style>
		body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; color: #1f2933; }
		.navbar { background: #111827; color: #fff; padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; }
		.nav-links a { color: #fff; margin-right: 14px; text-decoration: none; font-weight: 600; }
		.nav-links a:hover { text-decoration: underline; }
		.logout { color: #fca5a5; text-decoration: none; }
		.container { max-width: 900px; margin: 28px auto; padding: 0 16px; }
		.card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 4px 14px rgba(0,0,0,0.07); }
		table { width: 100%; border-collapse: collapse; margin-top: 10px; }
		th, td { text-align: left; padding: 10px; border-bottom: 1px solid #e5e7eb; }
		th { background: #f9fafb; }
	</style>
</head>
<body>
	<div class="navbar">
		<div class="nav-links">
			<a href="dashboard.php?view=home">Home</a>
			<a href="dashboard.php?view=users">User List</a>
		</div>
		<div>
			Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
			|
			<a class="logout" href="dashboard.php?logout=1">Logout</a>
		</div>
	</div>

	<div class="container">
		<div class="card">
			<?php if ($view === 'users'): ?>
				<h2>User List</h2>
				<?php if (count($users) === 0): ?>
					<p>No users found.</p>
				<?php else: ?>
					<table>
						<thead>
							<tr>
								<th>ID</th>
								<th>Username</th>
								<th>Created At</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($users as $user): ?>
								<tr>
									<td><?php echo (int)$user['id']; ?></td>
									<td><?php echo htmlspecialchars($user['username']); ?></td>
									<td><?php echo htmlspecialchars($user['created_at']); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			<?php else: ?>
				<h2>Home</h2>
				<p>Welcome to your dashboard, <?php echo htmlspecialchars($_SESSION['username']); ?>.</p>
				<p>Use the top navbar to open the User List page.</p>
			<?php endif; ?>
		</div>
	</div>
</body>
</html>
