<?php
session_start();

$timeout_duration = 5; 

// Check if session exists and if it's expired
if (isset($_SESSION['last_activity'])) {
    $duration = time() - $_SESSION['last_activity'];
    if ($duration > $timeout_duration) {
        // Destroy session and redirect
        session_unset();
        session_destroy();
        header("Location: login.php?expired=true");
        exit();
    }
} else {
    // No session found, redirect to login
    header("Location: login.php");
    exit();
}

// Update last activity time to current time
$_SESSION['last_activity'] = time();

?>