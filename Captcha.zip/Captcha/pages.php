<?php
session_start();
include 'config.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'home';


displayMenubar($conn, 3);

$section = getPageSection($conn, $page);

if ($section) {
    echo $section['section_title'];
    echo $section['section_content'];
} else {
    echo '<div style="padding: 40px;"><h2>Page Not Found</h2></div>';
}
?>