<?php
include 'config.php';
include 'check_session.php';

// If not logged in, redirect to login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$allowedPages = ['dashboard', 'users', 'courses', 'settings'];
if (!in_array($page, $allowedPages)) {
    $page = 'dashboard';
}


$message = '';

// Handle course actions
if ($page === 'courses') {
    if (isset($_POST['add_course'])) {
        $courseName = trim($_POST['course_name']);
        $courseDesc = trim($_POST['course_desc'] ?? '');
        if (strlen($courseName) >= 2) {
            if (addCourse($conn, $courseName, $courseDesc, $_SESSION['user_id'])) {
                $message = '<div class="success-msg">Course added successfully.</div>';
            } else {
                $message = '<div class="error-msg">Failed to add course.</div>';
            }
        } else {
            $message = '<div class="error-msg">Course name must be at least 2 characters.</div>';
        }
    }
    if (isset($_GET['delete'])) {
        $deleteId = (int)$_GET['delete'];
        deleteCourse($conn, $deleteId);
        header('Location: dashboard.php?page=courses&deleted=1');
        exit();
    }
    if (isset($_GET['deleted'])) {
        $message = '<div class="success-msg">Course deleted.</div>';
    }
}

// Handle settings actions
if ($page === 'settings' && isset($_POST['change_password'])) {
    $currentPwd = $_POST['current_password'];
    $newPwd = $_POST['new_password'];
    $confirmPwd = $_POST['confirm_new_password'];

    if (strlen($newPwd) < 6) {
        $message = '<div class="error-msg">New password must be at least 6 characters.</div>';
    } elseif ($newPwd !== $confirmPwd) {
        $message = '<div class="error-msg">New passwords do not match.</div>';
    } else {
        $result = changePassword($conn, $_SESSION['user_id'], $currentPwd, $newPwd);
        $msgClass = $result['success'] ? 'success-msg' : 'error-msg';
        $message = '<div class="' . $msgClass . '">' . htmlspecialchars($result['message']) . '</div>';
    }
}

// Display dashboard navigation
displayDashboardNav($conn, $page, $_SESSION['username']);

// Display page content
switch ($page) {
    case 'users':
        displayUserManagement($conn);
        break;
    case 'courses':
        displayCourseManagement($conn, $message);
        break;
    case 'settings':
        displaySettings($conn, $_SESSION['user_id'], $_SESSION['username'], $message);
        break;
    default:
        displayDashboard($conn, $_SESSION['username']);
        break;
}



