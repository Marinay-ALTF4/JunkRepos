<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "jela_db"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getMenuTemplate($conn, $id) {
    $sql = "SELECT * FROM menu_templates WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function displayMenubar($conn, $id) {
    $template = getMenuTemplate($conn, $id);
    
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        
        // Replace {{AUTH_LINK}} placeholder with Login or Logout link
        if (isset($_SESSION['user_id'])) {
            $authLink = '<a href="logout.php" class="auth-link">Logout</a>';
        } else {
            $authLink = '<a href="login.php" class="auth-link">Login</a>';
        }
        $html = str_replace('{{AUTH_LINK}}', $authLink, $html);
        
        echo $html;
        
        // Output JS protection script from database (hidden from source code)
        if (!empty($template['js_content'])) {
            echo '<script>' . $template['js_content'] . '</script>';
        }
    } else {
        echo "Template not found!";
    }
}

function getPageSection($conn, $page_name) {
    $sql = "SELECT * FROM page_sections WHERE page_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $page_name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// =============================================
// LOGIN / REGISTER FORM DISPLAY FUNCTIONS
// (HTML/CSS is stored in the database - hidden from source code)
// =============================================

function displayLoginForm($conn, $message = '') {
    $template = getMenuTemplate($conn, 4);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $html = str_replace('{{MESSAGE}}', $message, $html);
        echo $html;
    }
}

function displayRegisterForm($conn, $message = '') {
    $template = getMenuTemplate($conn, 5);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $html = str_replace('{{MESSAGE}}', $message, $html);
        echo $html;
    }
}

function displayDashboard($conn, $username) {
    $template = getMenuTemplate($conn, 6);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $html = str_replace('{{USERNAME}}', htmlspecialchars($username), $html);
        $html = str_replace('{{LOGIN_TIME}}', date('F j, Y - g:i A'), $html);

        $userCount = $conn->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
        $courseCount = 0;
        $courseResult = $conn->query("SELECT COUNT(*) as cnt FROM courses");
        if ($courseResult) {
            $courseCount = $courseResult->fetch_assoc()['cnt'];
        }
        $html = str_replace('{{TOTAL_USERS}}', $userCount, $html);
        $html = str_replace('{{TOTAL_COURSES}}', $courseCount, $html);

        echo $html;
    }
}

// =============================================
// AUTHENTICATION FUNCTIONS
// Username is hashed with SHA-256 (deterministic, for DB lookup)
// Password is hashed with BCRYPT via password_hash (salted, one-way)
// =============================================

function registerUser($conn, $username, $email, $password) {
    // Hash username with SHA-256 before storing/checking
    $hashedUsername = hash('sha256', strtolower(trim($username)));

    // Check if username already exists (compare hashes)
    $sql = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $hashedUsername);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return ['success' => false, 'message' => 'Username already exists!'];
    }

    // Check if email already exists
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return ['success' => false, 'message' => 'Email already registered!'];
    }

    // Hash password with BCRYPT (salted, one-way)
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $hashedUsername, $email, $hashedPassword);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Registration successful! You can now log in.'];
    }
    return ['success' => false, 'message' => 'Registration failed. Please try again.'];
}

function loginUser($conn, $username, $password) {
    // Hash the input username with SHA-256 to match stored hash
    $hashedUsername = hash('sha256', strtolower(trim($username)));

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $hashedUsername);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify BCRYPT hashed password
        if (password_verify($password, $user['password'])) {
            // Return original typed username for session display (not the hash)
            $user['display_username'] = $username;
            return ['success' => true, 'user' => $user];
        }
    }
    return ['success' => false, 'message' => 'Invalid username or password!'];
}

function verifyCaptcha($input) {
    if (isset($_SESSION['captcha']) && strtolower($input) === strtolower($_SESSION['captcha'])) {
        unset($_SESSION['captcha']);
        return true;
    }
    return false;
}

// =============================================
// DASHBOARD NAVIGATION & PAGE FUNCTIONS
// =============================================

function displayDashboardNav($conn, $activePage, $username) {
    $template = getMenuTemplate($conn, 7);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $html = str_replace('{{USERNAME}}', htmlspecialchars($username), $html);
        $html = str_replace('{{ACTIVE_DASHBOARD}}', $activePage === 'dashboard' ? 'active' : '', $html);
        $html = str_replace('{{ACTIVE_USERS}}', $activePage === 'users' ? 'active' : '', $html);
        $html = str_replace('{{ACTIVE_COURSES}}', $activePage === 'courses' ? 'active' : '', $html);
        $html = str_replace('{{ACTIVE_SETTINGS}}', $activePage === 'settings' ? 'active' : '', $html);
        echo $html;
        if (!empty($template['js_content'])) {
            echo '<script>' . $template['js_content'] . '</script>';
        }
    }
}

function displayUserManagement($conn) {
    $template = getMenuTemplate($conn, 8);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $result = $conn->query("SELECT id, email, created_at FROM users ORDER BY created_at DESC");
        $userCount = $result->num_rows;
        $rows = '';
        while ($user = $result->fetch_assoc()) {
            $rows .= '<tr><td>' . (int)$user['id'] . '</td><td>' . htmlspecialchars($user['email']) . '</td><td>' . date('M j, Y', strtotime($user['created_at'])) . '</td></tr>';
        }
        if (empty($rows)) {
            $rows = '<tr><td colspan="3" style="text-align:center;color:rgba(31,78,121,0.55);">No users found.</td></tr>';
        }
        $html = str_replace('{{USER_COUNT}}', $userCount, $html);
        $html = str_replace('{{USER_ROWS}}', $rows, $html);
        echo $html;
    }
}

function displayCourseManagement($conn, $message = '') {
    $template = getMenuTemplate($conn, 9);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $result = $conn->query("SELECT id, course_name, description, created_at FROM courses ORDER BY created_at DESC");
        $courseCount = $result ? $result->num_rows : 0;
        $table = '';
        if ($courseCount > 0) {
            $table = '<table class="lms-table"><thead><tr><th>ID</th><th>Course Name</th><th>Description</th><th>Created</th><th>Action</th></tr></thead><tbody>';
            while ($course = $result->fetch_assoc()) {
                $desc = htmlspecialchars(mb_substr($course['description'] ?? '', 0, 60));
                $table .= '<tr><td>' . (int)$course['id'] . '</td><td>' . htmlspecialchars($course['course_name']) . '</td><td>' . $desc . '</td><td>' . date('M j, Y', strtotime($course['created_at'])) . '</td><td><a href="dashboard.php?page=courses&amp;delete=' . (int)$course['id'] . '" class="lms-btn-sm" onclick="return confirm(\'Delete this course?\')">Delete</a></td></tr>';
            }
            $table .= '</tbody></table>';
        } else {
            $table = '<p class="lms-empty">No courses created yet.</p>';
        }
        $html = str_replace('{{MESSAGE}}', $message, $html);
        $html = str_replace('{{COURSE_COUNT}}', $courseCount, $html);
        $html = str_replace('{{COURSE_TABLE}}', $table, $html);
        echo $html;
    }
}

function displaySettings($conn, $userId, $username, $message = '') {
    $template = getMenuTemplate($conn, 10);
    if ($template) {
        echo "<style>" . $template['css_content'] . "</style>";
        $html = $template['html_content'];
        $stmt = $conn->prepare("SELECT email, created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $html = str_replace('{{MESSAGE}}', $message, $html);
        $html = str_replace('{{USERNAME}}', htmlspecialchars($username), $html);
        $html = str_replace('{{EMAIL}}', htmlspecialchars($user['email'] ?? ''), $html);
        $html = str_replace('{{CREATED_AT}}', isset($user['created_at']) ? date('F j, Y', strtotime($user['created_at'])) : 'N/A', $html);
        echo $html;
    }
}

function addCourse($conn, $name, $description, $createdBy) {
    $stmt = $conn->prepare("INSERT INTO courses (course_name, description, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $description, $createdBy);
    return $stmt->execute();
}

function deleteCourse($conn, $courseId) {
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->bind_param("i", $courseId);
    return $stmt->execute();
}

function changePassword($conn, $userId, $currentPassword, $newPassword) {
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if (!$user || !password_verify($currentPassword, $user['password'])) {
        return ['success' => false, 'message' => 'Current password is incorrect.'];
    }
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashedPassword, $userId);
    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Password updated successfully.'];
    }
    return ['success' => false, 'message' => 'Failed to update password.'];
}
