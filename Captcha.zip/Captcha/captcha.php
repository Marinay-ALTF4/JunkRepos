<?php
session_start();

// Generate random captcha code
$characters = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
$code = '';
for ($i = 0; $i < 6; $i++) {
    $code .= $characters[rand(0, strlen($characters) - 1)];
}
$_SESSION['captcha'] = $code;

// Create captcha image
$width = 200;
$height = 45;
$image = imagecreatetruecolor($width, $height);

// Colors — primary #1F4E79, light #EAF2FA
$bgColor = imagecolorallocate($image, 234, 242, 250);  // #EAF2FA
$textColor = imagecolorallocate($image, 31, 78, 121);   // #1F4E79
$noiseColor = imagecolorallocate($image, 31, 78, 121);  // #1F4E79
$lineColor = imagecolorallocate($image, 31, 78, 121);   // #1F4E79

// Fill background
imagefilledrectangle($image, 0, 0, $width, $height, $bgColor);

// Add noise lines
for ($i = 0; $i < 6; $i++) {
    imageline($image, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lineColor);
}

// Add noise dots
for ($i = 0; $i < 80; $i++) {
    imagesetpixel($image, rand(0, $width), rand(0, $height), $noiseColor);
}

// Add captcha text
$fontSize = 5;
$x = 15;
for ($i = 0; $i < strlen($code); $i++) {
    $y = rand(8, 18);
    imagestring($image, $fontSize, $x, $y, $code[$i], $textColor);
    $x += 22;
}

// Output image
header('Content-Type: image/png');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
imagepng($image);
imagedestroy($image);
?>
