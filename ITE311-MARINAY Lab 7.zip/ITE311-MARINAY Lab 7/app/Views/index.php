<?php include('app\Views\template.php'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="d-flex justify-content-center mt-5 pt-5">
    <div class="card p-4 border border-dark shadow-sm" style="max-width: 700px; width: 100%; background-color: #e9ecef;">
        <h1 class="mb-3" style="color: #000000ff;">Welcome to the Homepage</h1>
        <p style="color: #000000ff;">This is the main page.</p>
    </div>
</div>

</body>
</html>
