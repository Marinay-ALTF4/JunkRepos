﻿Public Class Table
    Private Sub Customer_Click(sender As Object, e As EventArgs) Handles Customer.Click
        Dim dash As New Dashboard()   ' Create instance of Dashboard
        dash.Show()                   ' Show Dashboard form
        Me.Hide()                     ' Hide current form (optional)
    End Sub
End Class
