﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        DataGridView1 = New DataGridView()
        Update = New Button()
        Register = New Button()
        Delete = New Button()
        Back = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 50F)
        Label1.Location = New Point(142, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(485, 89)
        Label1.TabIndex = 0
        Label1.Text = "Customer Page"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 119)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(776, 209)
        DataGridView1.TabIndex = 1
        ' 
        ' Update
        ' 
        Update.Location = New Point(26, 334)
        Update.Name = "Update"
        Update.Size = New Size(125, 51)
        Update.TabIndex = 2
        Update.Text = "Update"
        Update.UseVisualStyleBackColor = True
        ' 
        ' Register
        ' 
        Register.Location = New Point(224, 334)
        Register.Name = "Register"
        Register.Size = New Size(125, 51)
        Register.TabIndex = 3
        Register.Text = "Register"
        Register.UseVisualStyleBackColor = True
        ' 
        ' Delete
        ' 
        Delete.Location = New Point(419, 334)
        Delete.Name = "Delete"
        Delete.Size = New Size(125, 51)
        Delete.TabIndex = 4
        Delete.Text = "Delete"
        Delete.UseVisualStyleBackColor = True
        ' 
        ' Back
        ' 
        Back.Location = New Point(623, 334)
        Back.Name = "Back"
        Back.Size = New Size(125, 51)
        Back.TabIndex = 5
        Back.Text = "Back"
        Back.UseVisualStyleBackColor = True
        ' 
        ' Dashboard
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Back)
        Controls.Add(Delete)
        Controls.Add(Register)
        Controls.Add(Update)
        Controls.Add(DataGridView1)
        Controls.Add(Label1)
        Name = "Dashboard"
        Text = "Dashboard"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Update As Button
    Friend WithEvents Register As Button
    Friend WithEvents Delete As Button
    Friend WithEvents Back As Button
End Class
