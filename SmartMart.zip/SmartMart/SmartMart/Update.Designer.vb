﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Update
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Back = New Button()
        Updates = New Button()
        TxtCity = New TextBox()
        TxtName = New TextBox()
        TxtAddress = New TextBox()
        TxtContact = New TextBox()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        TextBox1 = New TextBox()
        TxtLoyalty = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 50F)
        Label1.Location = New Point(121, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(557, 89)
        Label1.TabIndex = 0
        Label1.Text = "Customer Update"
        ' 
        ' Back
        ' 
        Back.Location = New Point(463, 361)
        Back.Name = "Back"
        Back.Size = New Size(128, 42)
        Back.TabIndex = 20
        Back.Text = "Back"
        Back.UseVisualStyleBackColor = True
        ' 
        ' Updates
        ' 
        Updates.Location = New Point(238, 361)
        Updates.Name = "Updates"
        Updates.Size = New Size(128, 42)
        Updates.TabIndex = 19
        Updates.Text = "Update"
        Updates.UseVisualStyleBackColor = True
        ' 
        ' TxtCity
        ' 
        TxtCity.Location = New Point(297, 218)
        TxtCity.Name = "TxtCity"
        TxtCity.Size = New Size(328, 23)
        TxtCity.TabIndex = 18
        ' 
        ' TxtName
        ' 
        TxtName.Location = New Point(295, 111)
        TxtName.Name = "TxtName"
        TxtName.Size = New Size(328, 23)
        TxtName.TabIndex = 17
        ' 
        ' TxtAddress
        ' 
        TxtAddress.Location = New Point(295, 165)
        TxtAddress.Name = "TxtAddress"
        TxtAddress.Size = New Size(328, 23)
        TxtAddress.TabIndex = 16
        ' 
        ' TxtContact
        ' 
        TxtContact.Location = New Point(297, 271)
        TxtContact.Name = "TxtContact"
        TxtContact.Size = New Size(328, 23)
        TxtContact.TabIndex = 15
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 20F)
        Label5.Location = New Point(160, 151)
        Label5.Name = "Label5"
        Label5.Size = New Size(117, 37)
        Label5.TabIndex = 14
        Label5.Text = "Address:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 20F)
        Label4.Location = New Point(160, 204)
        Label4.Name = "Label4"
        Label4.Size = New Size(69, 37)
        Label4.TabIndex = 13
        Label4.Text = "City:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 20F)
        Label3.Location = New Point(160, 257)
        Label3.Name = "Label3"
        Label3.Size = New Size(131, 37)
        Label3.TabIndex = 12
        Label3.Text = "Contact#:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 20F)
        Label2.Location = New Point(160, 97)
        Label2.Name = "Label2"
        Label2.Size = New Size(101, 37)
        Label2.TabIndex = 11
        Label2.Text = "Name: "
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(297, 322)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(328, 23)
        TextBox1.TabIndex = 22
        ' 
        ' TxtLoyalty
        ' 
        TxtLoyalty.AutoSize = True
        TxtLoyalty.Font = New Font("Segoe UI", 20F)
        TxtLoyalty.Location = New Point(104, 308)
        TxtLoyalty.Name = "TxtLoyalty"
        TxtLoyalty.Size = New Size(187, 37)
        TxtLoyalty.TabIndex = 21
        TxtLoyalty.Text = "Loyalty Points:"
        ' 
        ' Update
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(TextBox1)
        Controls.Add(TxtLoyalty)
        Controls.Add(Back)
        Controls.Add(Updates)
        Controls.Add(TxtCity)
        Controls.Add(TxtName)
        Controls.Add(TxtAddress)
        Controls.Add(TxtContact)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Update"
        Text = "Update"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Back As Button
    Friend WithEvents Updates As Button
    Friend WithEvents TxtCity As TextBox
    Friend WithEvents TxtName As TextBox
    Friend WithEvents TxtAddress As TextBox
    Friend WithEvents TxtContact As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TxtLoyalty As Label
End Class
