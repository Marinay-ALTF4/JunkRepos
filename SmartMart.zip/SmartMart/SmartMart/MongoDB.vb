﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class MongoDBConnection
    ' MongoDB client and database
    Private Shared client As MongoClient
    Private Shared database As IMongoDatabase

    ' Initialize connection
    Public Shared Sub Connect()
        ' Replace with your connection string
        ' Local MongoDB: "mongodb://localhost:27017"
        ' Atlas: "mongodb+srv://username:password@cluster.mongodb.net/test"
        client = New MongoClient("mongodb://localhost:27017")
        database = client.GetDatabase("SmartMartDB") ' Your database name
    End Sub

    ' Get Customers collection
    Public Shared Function GetCustomersCollection() As IMongoCollection(Of BsonDocument)
        Return database.GetCollection(Of BsonDocument)("Customers")
    End Function
End Class
