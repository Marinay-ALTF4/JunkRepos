﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Update

    ' Store the index of the row to update
    Private rowIndex As Integer
    Private originalName As String
    Private originalContact As String

    ' ===== LOAD CUSTOMER DATA =====
    Public Sub LoadCustomer(n As String, a As String, c As String, ct As String)
        TxtName.Text = n
        TxtAddress.Text = a
        TxtCity.Text = c
        TxtContact.Text = ct

        ' Store selected row index and original key values from Dashboard
        rowIndex = Dashboard.DataGridView1.SelectedRows(0).Index
        originalName = n
        originalContact = ct
    End Sub

    ' ===== UPDATE BUTTON =====
    Private Sub Update_Click(sender As Object, e As EventArgs) Handles Updates.Click

        ' Validate fields
        If TxtName.Text = "" Or TxtAddress.Text = "" Or TxtCity.Text = "" Or TxtContact.Text = "" Then
            MsgBox("Please fill out all fields.")
            Exit Sub
        End If

        ' --- Update MongoDB ---
        MongoDBConnection.Connect()
        Dim collection = MongoDBConnection.GetCustomersCollection()

        ' Filter by original Name + Contact (assumes unique combination)
        Dim filter = Builders(Of BsonDocument).Filter.And(
            Builders(Of BsonDocument).Filter.Eq("Name", originalName),
            Builders(Of BsonDocument).Filter.Eq("Contact", originalContact)
        )

        ' Update document values
        Dim update = Builders(Of BsonDocument).Update.Set("Name", TxtName.Text) _
                                                     .Set("Address", TxtAddress.Text) _
                                                     .Set("City", TxtCity.Text) _
                                                     .Set("Contact", TxtContact.Text)

        collection.UpdateOne(filter, update)

        ' --- Update DataGridView ---
        With Dashboard.DataGridView1.Rows(rowIndex)
            .Cells(0).Value = TxtName.Text
            .Cells(1).Value = TxtAddress.Text
            .Cells(2).Value = TxtCity.Text
            .Cells(3).Value = TxtContact.Text
        End With

        MsgBox("Customer updated successfully!")
    End Sub

    ' ===== BACK BUTTON =====
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Dashboard.Show()
        Me.Hide()
    End Sub

End Class
