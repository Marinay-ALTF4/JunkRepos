﻿Imports MongoDB.Bson
Imports MongoDB.Driver

Public Class Dashboard

    ' ===== DASHBOARD LOAD =====
    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCustomersFromDB()
    End Sub

    ' ===== LOAD CUSTOMERS FROM DATABASE =====
    Public Sub LoadCustomersFromDB()
        MongoDBConnection.Connect()
        Dim collection = MongoDBConnection.GetCustomersCollection()

        ' Clear existing rows
        DataGridView1.Rows.Clear()

        ' Fetch all customers
        Dim customers = collection.Find(New BsonDocument()).ToList()
        For Each cust In customers
            DataGridView1.Rows.Add(cust("Name").AsString, cust("Address").AsString, cust("City").AsString, cust("Contact").AsString)
        Next
    End Sub

    ' ===== UPDATE BUTTON =====
    Private Sub Update_Click(sender As Object, e As EventArgs) Handles Update.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox("Please select a customer to update.")
            Exit Sub
        End If

        ' Create a new instance of Update form
        Dim upd As New Update()

        ' Load selected row data into Update form
        upd.LoadCustomer(
            DataGridView1.SelectedRows(0).Cells(0).Value,
            DataGridView1.SelectedRows(0).Cells(1).Value,
            DataGridView1.SelectedRows(0).Cells(2).Value,
            DataGridView1.SelectedRows(0).Cells(3).Value
        )

        ' Show the Update form
        upd.Show()
        Me.Hide()
    End Sub

    ' ===== REGISTER BUTTON =====
    Private Sub Register_Click(sender As Object, e As EventArgs) Handles Register.Click
        Dim reg As New Register()
        reg.Show()
        Me.Hide()
    End Sub

    ' ===== DELETE BUTTON =====
    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox("Please select a customer to delete.")
            Exit Sub
        End If

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this customer?",
                                                     "Delete Customer",
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Warning)
        If result = DialogResult.Yes Then
            ' --- Delete from MongoDB ---
            MongoDBConnection.Connect()
            Dim collection = MongoDBConnection.GetCustomersCollection()

            ' Filter by Name + Contact (assuming combination is unique)
            Dim filter = Builders(Of BsonDocument).Filter.And(
    Builders(Of BsonDocument).Filter.Eq("Name", DataGridView1.SelectedRows(0).Cells(0).Value.ToString()),
    Builders(Of BsonDocument).Filter.Eq("Contact", DataGridView1.SelectedRows(0).Cells(3).Value.ToString())
)


            collection.DeleteOne(filter)

            ' Remove from DataGridView
            DataGridView1.Rows.Remove(DataGridView1.SelectedRows(0))
            MsgBox("Customer deleted successfully from database!")
        End If
    End Sub

    ' ===== BACK BUTTON =====
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Dim tbl As New Table()
        tbl.Show()
        Me.Hide()
    End Sub

End Class
