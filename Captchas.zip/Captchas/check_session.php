<?php
session_start();

$timeout_duration = 900;

// User must be logged in first
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if session is expired
if (isset($_SESSION['last_activity'])) {
    $duration = time() - (int) $_SESSION['last_activity'];
    if ($duration > $timeout_duration) {
        session_unset();
        session_destroy();
        header("Location: login.php?expired=true");
        exit();
    }
}

// Refresh activity timestamp
$_SESSION['last_activity'] = time();

?>