<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Timeout</title>
</head>
<body>

<div>
    <p>You are Logout! Login in Again</p>
</div>
    
</body>
</html>