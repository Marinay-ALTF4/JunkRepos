<?php
session_start();
include 'config.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$message = '';

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $captchaInput = trim($_POST['captcha']);

    // Validate captcha
    if (!verifyCaptcha($captchaInput)) {
        $message = '<div class="error-msg">Invalid captcha! Please try again.</div>';
    } elseif (strlen($username) < 3) {
        $message = '<div class="error-msg">Username must be at least 3 characters!</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = '<div class="error-msg">Please enter a valid email address!</div>';
    } elseif (strlen($password) < 6) {
        $message = '<div class="error-msg">Password must be at least 6 characters!</div>';
    } elseif ($password !== $confirmPassword) {
        $message = '<div class="error-msg">Passwords do not match!</div>';
    } else {
        $result = registerUser($conn, $username, $email, $password);
        if ($result['success']) {
            $message = '<div class="success-msg">' . htmlspecialchars($result['message']) . '</div>';
        } else {
            $message = '<div class="error-msg">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

displayMenubar($conn, 3);
displayRegisterForm($conn, $message);
?>
