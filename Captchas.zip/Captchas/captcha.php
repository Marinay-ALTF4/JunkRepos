<?php
session_start();

// Generate math captcha (e.g., 3 + 7)
$first = random_int(1, 9);
$second = random_int(1, 9);
$_SESSION['captcha_question'] = $first . " + " . $second;
$_SESSION['captcha_answer'] = (string) ($first + $second);
$_SESSION['captcha_expires'] = time() + 120;

// Create captcha image
$width = 220;
$height = 60;
$image = imagecreatetruecolor($width, $height);

// Colors — primary #1F4E79, light #EAF2FA
$bgColor = imagecolorallocate($image, 234, 242, 250);  // #EAF2FA
$textColor = imagecolorallocate($image, 31, 78, 121);   // #1F4E79
$noiseColor = imagecolorallocate($image, 31, 78, 121);  // #1F4E79
$lineColor = imagecolorallocate($image, 31, 78, 121);   // #1F4E79
$accentColor = imagecolorallocate($image, 58, 122, 173);

// Fill background
imagefilledrectangle($image, 0, 0, $width, $height, $bgColor);

// Add gentle vertical gradient stripes
for ($x = 0; $x < $width; $x += 2) {
    $alpha = 115 + (int)(35 * sin($x / 18));
    $stripeColor = imagecolorallocatealpha($image, 31, 78, 121, max(80, min(127, $alpha)));
    imageline($image, $x, 0, $x, $height, $stripeColor);
}

// Add crossing noise lines
for ($i = 0; $i < 8; $i++) {
    imageline(
        $image,
        random_int(0, $width),
        random_int(0, $height),
        random_int(0, $width),
        random_int(0, $height),
        $lineColor
    );
}

// Add noise dots
for ($i = 0; $i < 260; $i++) {
    imagesetpixel($image, random_int(0, $width - 1), random_int(0, $height - 1), $noiseColor);
}

// Add captcha question text
$fontSize = 5;
$question = $_SESSION['captcha_question'] . " = ?";
imagestring($image, $fontSize, 52, 22, $question, $textColor);

// Output image
header('Content-Type: image/png');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
imagepng($image);
imagedestroy($image);
?>
