<?php
include 'config.php';
include 'check_session.php';

// If not logged in, redirect to login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$allowedPages = ['dashboard', 'users'];
if (!in_array($page, $allowedPages)) {
    $page = 'dashboard';
}

// Display dashboard navigation
displayDashboardNav($conn, $page, $_SESSION['username']);

// Display page content
switch ($page) {
    case 'users':
        displayUserManagement($conn);
        break;
    default:
        displayDashboard($conn, $_SESSION['username']);
        break;
}



