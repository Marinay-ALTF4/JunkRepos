<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "captcha";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getMenuTemplate($conn, $id) {
    $sql = "SELECT * FROM menu_templates WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function displayMenubar($conn, $id) {
    if (isset($_SESSION['user_id'])) {
        $authLink = '<a href="dashboard.php">Dashboard</a><a href="logout.php">Logout</a>';
    } else {
        $authLink = '<a href="login.php">Login</a><a href="register.php">Register</a>';
    }

    echo '<style>
        body{margin:0;background:#f7f9fc;font-family:Arial,sans-serif}
        .simple-topnav{max-width:960px;margin:14px auto;padding:10px 14px;background:#fff;border:1px solid #d7e3f0;border-radius:8px;display:flex;justify-content:space-between;align-items:center}
        .simple-topnav .brand{font-size:18px;font-weight:700;color:#1f4e79;text-decoration:none}
        .simple-topnav .links{display:flex;gap:8px}
        .simple-topnav .links a{color:#1f4e79;text-decoration:none;padding:7px 10px;border-radius:6px;border:1px solid #d7e3f0}
    </style>';

    echo '<div class="simple-topnav">
        <a class="brand" href="pages.php">Captcha App</a>
        <div class="links">
            <a href="pages.php">Home</a>
            ' . $authLink . '
        </div>
    </div>';
}

function getPageSection($conn, $page_name) {
    $sql = "SELECT * FROM page_sections WHERE page_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $page_name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// LOGIN / REGISTER FORM DISPLAY FUNCTIONS
// (HTML/CSS is stored in the database - hidden from source code)


function displayLoginForm($conn, $message = '') {
    echo '<style>
        .simple-auth-wrap{max-width:420px;margin:30px auto;padding:20px;border:1px solid #d7e3f0;border-radius:8px;background:#fff;font-family:Arial,sans-serif}
        .simple-auth-wrap h2{margin:0 0 14px 0;color:#1f4e79;font-size:24px}
        .simple-auth-wrap .field{margin-bottom:12px}
        .simple-auth-wrap label{display:block;margin-bottom:5px;font-weight:600;color:#1f4e79}
        .simple-auth-wrap input{width:100%;padding:10px;border:1px solid #c7d5e3;border-radius:6px;font-size:14px}
        .simple-auth-wrap button{width:100%;padding:10px;border:0;background:#1f4e79;color:#fff;border-radius:6px;cursor:pointer}
        .simple-auth-wrap button:hover{background:#173a5a}
        .simple-auth-wrap .captcha-row{display:flex;gap:8px;align-items:center;margin-bottom:8px}
        .simple-auth-wrap .captcha-row img{height:48px;border:1px solid #c7d5e3;border-radius:4px}
        .simple-auth-wrap .refresh-btn{width:42px;height:42px;padding:0;background:#f2f7fc;color:#1f4e79;border:1px solid #c7d5e3}
        .simple-auth-wrap .form-link{margin-top:12px;text-align:center;font-size:14px}
        .error-msg,.success-msg{padding:10px;border-radius:6px;margin-bottom:12px;font-size:14px}
        .error-msg{background:#ffecec;color:#b30000;border:1px solid #f5baba}
        .success-msg{background:#eefcf0;color:#126b1b;border:1px solid #b7e6be}
    </style>';

    echo '<div class="simple-auth-wrap">
        <h2>Login</h2>
        ' . $message . '
        <form method="POST" action="">
            <div class="field">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="field">
                <label for="captcha">Solve captcha</label>
                <div class="captcha-row">
                    <img src="captcha.php" alt="captcha" id="captcha-img">
                    <button type="button" class="refresh-btn" onclick="document.getElementById(\'captcha-img\').src=\'captcha.php?\'+Math.random()">↻</button>
                </div>
                <input type="text" id="captcha" name="captcha" placeholder="Enter answer" required>
            </div>
            <button type="submit" name="login">Log In</button>
        </form>
        <p class="form-link">No account? <a href="register.php">Register</a></p>
    </div>';
}

function displayRegisterForm($conn, $message = '') {
    echo '<style>
        .simple-auth-wrap{max-width:420px;margin:30px auto;padding:20px;border:1px solid #d7e3f0;border-radius:8px;background:#fff;font-family:Arial,sans-serif}
        .simple-auth-wrap h2{margin:0 0 14px 0;color:#1f4e79;font-size:24px}
        .simple-auth-wrap .field{margin-bottom:12px}
        .simple-auth-wrap label{display:block;margin-bottom:5px;font-weight:600;color:#1f4e79}
        .simple-auth-wrap input{width:100%;padding:10px;border:1px solid #c7d5e3;border-radius:6px;font-size:14px}
        .simple-auth-wrap button{width:100%;padding:10px;border:0;background:#1f4e79;color:#fff;border-radius:6px;cursor:pointer}
        .simple-auth-wrap button:hover{background:#173a5a}
        .simple-auth-wrap .captcha-row{display:flex;gap:8px;align-items:center;margin-bottom:8px}
        .simple-auth-wrap .captcha-row img{height:48px;border:1px solid #c7d5e3;border-radius:4px}
        .simple-auth-wrap .refresh-btn{width:42px;height:42px;padding:0;background:#f2f7fc;color:#1f4e79;border:1px solid #c7d5e3}
        .simple-auth-wrap .form-link{margin-top:12px;text-align:center;font-size:14px}
        .error-msg,.success-msg{padding:10px;border-radius:6px;margin-bottom:12px;font-size:14px}
        .error-msg{background:#ffecec;color:#b30000;border:1px solid #f5baba}
        .success-msg{background:#eefcf0;color:#126b1b;border:1px solid #b7e6be}
    </style>';

    echo '<div class="simple-auth-wrap">
        <h2>Register</h2>
        ' . $message . '
        <form method="POST" action="">
            <div class="field">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="field">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <div class="field">
                <label for="captcha">Solve captcha</label>
                <div class="captcha-row">
                    <img src="captcha.php" alt="captcha" id="captcha-img">
                    <button type="button" class="refresh-btn" onclick="document.getElementById(\'captcha-img\').src=\'captcha.php?\'+Math.random()">↻</button>
                </div>
                <input type="text" id="captcha" name="captcha" placeholder="Enter answer" required>
            </div>
            <button type="submit" name="register">Create Account</button>
        </form>
        <p class="form-link">Already have an account? <a href="login.php">Log in</a></p>
    </div>';
}

function displayDashboard($conn, $username) {
    $userCount = $conn->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
    $courseCount = 0;
    $courseResult = $conn->query("SELECT COUNT(*) as cnt FROM courses");
    if ($courseResult) {
        $courseCount = $courseResult->fetch_assoc()['cnt'];
    }

    echo '<style>
        .simple-dash{max-width:800px;margin:20px auto;padding:16px;font-family:Arial,sans-serif}
        .simple-dash h2{margin:0 0 8px 0;color:#1f4e79}
        .simple-dash p{margin:0 0 14px 0;color:#444}
        .simple-cards{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .simple-card{border:1px solid #d7e3f0;border-radius:8px;padding:14px;background:#fff}
        .simple-card .label{font-size:13px;color:#777}
        .simple-card .value{font-size:24px;font-weight:700;color:#1f4e79}
    </style>';

    echo '<div class="simple-dash">
        <h2>Dashboard</h2>
        <p>Welcome, ' . htmlspecialchars($username) . '. Logged in at ' . date('F j, Y - g:i A') . '.</p>
        <div class="simple-cards">
            <div class="simple-card"><div class="label">Total Users</div><div class="value">' . (int)$userCount . '</div></div>
            <div class="simple-card"><div class="label">Total Courses</div><div class="value">' . (int)$courseCount . '</div></div>
        </div>
    </div>';
}

// AUTHENTICATION FUNCTIONS
// Username is hashed with SHA-256 (deterministic, for DB lookup)
// Password is hashed with BCRYPT via password_hash (salted, one-way)

function registerUser($conn, $username, $email, $password) {
    // Hash username with SHA-256 before storing/checking
    $hashedUsername = hash('sha256', strtolower(trim($username)));

    // Check if username already exists (compare hashes)
    $sql = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $hashedUsername);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return ['success' => false, 'message' => 'Username already exists!'];
    }

    // Check if email already exists
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return ['success' => false, 'message' => 'Email already registered!'];
    }

    // Hash password with BCRYPT (salted, one-way)
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $hashedUsername, $email, $hashedPassword);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Registration successful! You can now log in.'];
    }
    return ['success' => false, 'message' => 'Registration failed. Please try again.'];
}

function loginUser($conn, $username, $password) {
    // Hash the input username with SHA-256 to match stored hash
    $hashedUsername = hash('sha256', strtolower(trim($username)));

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $hashedUsername);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify BCRYPT hashed password
        if (password_verify($password, $user['password'])) {
            // Return original typed username for session display (not the hash)
            $user['display_username'] = $username;
            return ['success' => true, 'user' => $user];
        }
    }
    return ['success' => false, 'message' => 'Invalid username or password!'];
}

function createCaptcha() {
    $first = random_int(1, 9);
    $second = random_int(1, 9);
    $_SESSION['captcha_question'] = $first . " + " . $second;
    $_SESSION['captcha_answer'] = (string) ($first + $second);
    $_SESSION['captcha_expires'] = time() + 120;
}

function verifyCaptcha($input) {
    if (
        isset($_SESSION['captcha_answer'], $_SESSION['captcha_expires']) &&
        time() <= (int) $_SESSION['captcha_expires'] &&
        trim($input) === (string) $_SESSION['captcha_answer']
    ) {
        unset($_SESSION['captcha_question'], $_SESSION['captcha_answer'], $_SESSION['captcha_expires']);
        return true;
    }

    unset($_SESSION['captcha_question'], $_SESSION['captcha_answer'], $_SESSION['captcha_expires']);
    return false;
}

// DASHBOARD NAVIGATION & PAGE FUNCTIONS


function displayDashboardNav($conn, $activePage, $username) {
    $dashboardClass = $activePage === 'dashboard' ? 'active' : '';
    $usersClass = $activePage === 'users' ? 'active' : '';

    echo '<style>
        .simple-nav{max-width:900px;margin:15px auto;padding:10px 14px;border:1px solid #d7e3f0;border-radius:8px;background:#fff;display:flex;justify-content:space-between;align-items:center;font-family:Arial,sans-serif}
        .simple-nav .left,.simple-nav .right{display:flex;align-items:center;gap:8px}
        .simple-nav a{padding:7px 10px;border-radius:6px;text-decoration:none;color:#1f4e79;border:1px solid transparent}
        .simple-nav a.active{background:#1f4e79;color:#fff}
        .simple-nav .welcome{font-size:14px;color:#444;margin-right:8px}
    </style>';

    echo '<div class="simple-nav">
        <div class="left">
            <a class="' . $dashboardClass . '" href="dashboard.php?page=dashboard">Dashboard</a>
            <a class="' . $usersClass . '" href="dashboard.php?page=users">Users</a>
        </div>
        <div class="right">
            <span class="welcome">' . htmlspecialchars($username) . '</span>
            <a href="logout.php">Logout</a>
        </div>
    </div>';
}

function displayUserManagement($conn) {
    $result = $conn->query("SELECT id, email, created_at FROM users ORDER BY created_at DESC");
    $userCount = $result ? $result->num_rows : 0;

    echo '<style>
        .simple-panel{max-width:900px;margin:14px auto;padding:16px;background:#fff;border:1px solid #d7e3f0;border-radius:8px;font-family:Arial,sans-serif}
        .simple-panel h3{margin:0 0 12px 0;color:#1f4e79}
        .simple-table{width:100%;border-collapse:collapse}
        .simple-table th,.simple-table td{border-bottom:1px solid #e6edf5;padding:10px;text-align:left;font-size:14px}
        .simple-muted{color:#666;font-size:14px;margin-bottom:10px}
    </style>';

    echo '<div class="simple-panel"><h3>Users</h3><div class="simple-muted">Total users: ' . (int)$userCount . '</div><table class="simple-table"><thead><tr><th>ID</th><th>Email</th><th>Created</th></tr></thead><tbody>';
    if ($result && $userCount > 0) {
        while ($user = $result->fetch_assoc()) {
            echo '<tr><td>' . (int)$user['id'] . '</td><td>' . htmlspecialchars($user['email']) . '</td><td>' . date('M j, Y', strtotime($user['created_at'])) . '</td></tr>';
        }
    } else {
        echo '<tr><td colspan="3">No users found.</td></tr>';
    }
    echo '</tbody></table></div>';
}

function displayCourseManagement($conn, $message = '') {
    $result = $conn->query("SELECT id, course_name, description, created_at FROM courses ORDER BY created_at DESC");
    $courseCount = $result ? $result->num_rows : 0;

    echo '<style>
        .simple-panel{max-width:900px;margin:14px auto;padding:16px;background:#fff;border:1px solid #d7e3f0;border-radius:8px;font-family:Arial,sans-serif}
        .simple-panel h3{margin:0 0 12px 0;color:#1f4e79}
        .simple-form{display:grid;grid-template-columns:1fr;gap:8px;margin-bottom:14px}
        .simple-form input,.simple-form textarea{padding:10px;border:1px solid #c7d5e3;border-radius:6px;font-size:14px}
        .simple-form button{padding:10px;border:0;border-radius:6px;background:#1f4e79;color:#fff;cursor:pointer}
        .simple-table{width:100%;border-collapse:collapse}
        .simple-table th,.simple-table td{border-bottom:1px solid #e6edf5;padding:10px;text-align:left;font-size:14px}
        .error-msg,.success-msg{padding:10px;border-radius:6px;margin-bottom:12px;font-size:14px}
        .error-msg{background:#ffecec;color:#b30000;border:1px solid #f5baba}
        .success-msg{background:#eefcf0;color:#126b1b;border:1px solid #b7e6be}
    </style>';

    echo '<div class="simple-panel">
        <h3>Courses</h3>
        ' . $message . '
        <form method="POST" class="simple-form" action="">
            <input type="text" name="course_name" placeholder="Course name" required>
            <textarea name="course_desc" placeholder="Description" rows="3"></textarea>
            <button type="submit" name="add_course">Add Course</button>
        </form>
        <div style="margin-bottom:10px;color:#666;font-size:14px;">Total courses: ' . (int)$courseCount . '</div>
        <table class="simple-table"><thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Created</th><th>Action</th></tr></thead><tbody>';

    if ($result && $courseCount > 0) {
        while ($course = $result->fetch_assoc()) {
            $desc = htmlspecialchars(mb_substr($course['description'] ?? '', 0, 80));
            echo '<tr><td>' . (int)$course['id'] . '</td><td>' . htmlspecialchars($course['course_name']) . '</td><td>' . $desc . '</td><td>' . date('M j, Y', strtotime($course['created_at'])) . '</td><td><a href="dashboard.php?page=courses&amp;delete=' . (int)$course['id'] . '" onclick="return confirm(\'Delete this course?\')">Delete</a></td></tr>';
        }
    } else {
        echo '<tr><td colspan="5">No courses created yet.</td></tr>';
    }

    echo '</tbody></table></div>';
}

function displaySettings($conn, $userId, $username, $message = '') {
    $stmt = $conn->prepare("SELECT email, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    echo '<style>
        .simple-panel{max-width:700px;margin:14px auto;padding:16px;background:#fff;border:1px solid #d7e3f0;border-radius:8px;font-family:Arial,sans-serif}
        .simple-panel h3{margin:0 0 12px 0;color:#1f4e79}
        .simple-meta{font-size:14px;color:#444;margin-bottom:12px;line-height:1.6}
        .simple-form{display:grid;grid-template-columns:1fr;gap:8px}
        .simple-form input{padding:10px;border:1px solid #c7d5e3;border-radius:6px;font-size:14px}
        .simple-form button{padding:10px;border:0;border-radius:6px;background:#1f4e79;color:#fff;cursor:pointer}
        .error-msg,.success-msg{padding:10px;border-radius:6px;margin-bottom:12px;font-size:14px}
        .error-msg{background:#ffecec;color:#b30000;border:1px solid #f5baba}
        .success-msg{background:#eefcf0;color:#126b1b;border:1px solid #b7e6be}
    </style>';

    echo '<div class="simple-panel">
        <h3>Settings</h3>
        ' . $message . '
        <div class="simple-meta">
            <div><strong>Username:</strong> ' . htmlspecialchars($username) . '</div>
            <div><strong>Email:</strong> ' . htmlspecialchars($user['email'] ?? '') . '</div>
            <div><strong>Member since:</strong> ' . (isset($user['created_at']) ? date('F j, Y', strtotime($user['created_at'])) : 'N/A') . '</div>
        </div>
        <form method="POST" class="simple-form" action="">
            <input type="password" name="current_password" placeholder="Current password" required>
            <input type="password" name="new_password" placeholder="New password" required>
            <input type="password" name="confirm_new_password" placeholder="Confirm new password" required>
            <button type="submit" name="change_password">Change Password</button>
        </form>
    </div>';
}

function addCourse($conn, $name, $description, $createdBy) {
    $stmt = $conn->prepare("INSERT INTO courses (course_name, description, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $description, $createdBy);
    return $stmt->execute();
}

function deleteCourse($conn, $courseId) {
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->bind_param("i", $courseId);
    return $stmt->execute();
}

function changePassword($conn, $userId, $currentPassword, $newPassword) {
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if (!$user || !password_verify($currentPassword, $user['password'])) {
        return ['success' => false, 'message' => 'Current password is incorrect.'];
    }
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashedPassword, $userId);
    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Password updated successfully.'];
    }
    return ['success' => false, 'message' => 'Failed to update password.'];
}
