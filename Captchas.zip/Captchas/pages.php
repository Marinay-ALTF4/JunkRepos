<?php
session_start();
include 'config.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'home';


displayMenubar($conn, 3);

$section = getPageSection($conn, $page);

if ($section) {
    echo '<style>
        .simple-page{max-width:960px;margin:14px auto;padding:20px;background:#fff;border:1px solid #d7e3f0;border-radius:8px;font-family:Arial,sans-serif}
        .simple-page h1,.simple-page h2,.simple-page h3{color:#1f4e79;margin-top:0}
        .simple-page p{line-height:1.6;color:#333}
    </style>';
    echo '<div class="simple-page">';
    echo $section['section_title'];
    echo $section['section_content'];
    echo '</div>';
} else {
    echo '<div class="simple-page"><h2>Page Not Found</h2><p>The page you requested does not exist.</p></div>';
}
?>