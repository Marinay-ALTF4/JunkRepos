<?php
session_start();
include 'config.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}


$message = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $captchaInput = trim($_POST['captcha']);

    // Verify captcha first
    if (!verifyCaptcha($captchaInput)) {
        $message = '<div class="error-msg">Invalid captcha! Please try again.</div>';
    } else {
        $result = loginUser($conn, $username, $password);
        if ($result['success']) {
            $_SESSION['user_id'] = $result['user']['id'];
            $_SESSION['username'] = $result['user']['display_username'];
            $_SESSION['last_activity'] = time();
            header('Location: dashboard.php');
            exit();
        } else {
            $message = '<div class="error-msg">' . htmlspecialchars($result['message']) . '</div>';
        }
    }
}

displayMenubar($conn, 3);
displayLoginForm($conn, $message);
?>
